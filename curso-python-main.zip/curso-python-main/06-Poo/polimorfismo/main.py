from persona import Persona, Atleta, Ciclista

persona = Persona('Alex')
persona.moverse()

atleta = Atleta('Roel')
atleta.moverse()

ciclista = Ciclista('Juan')
ciclista.moverse()

from persona import Persona

persona1 = Persona('Alex', 25)
persona1.mostra_datos()

persona1.nombre = 'Roel'
persona1.mostra_datos()

print(persona1)

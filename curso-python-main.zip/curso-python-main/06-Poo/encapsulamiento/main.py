from persona import Persona

persona1 = Persona('Alex', 25)
persona1.set_nombre('Roel')
#persona1.__metodo_privado()

print(persona1.get_nombre())
print(persona1)
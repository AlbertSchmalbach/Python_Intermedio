
datos = ['Alex', 'Roel', 25, 1.67, True]

"""
for dato in datos:
    print(dato)
"""

"""
c = 0
while c < len(datos):
    print(datos[c])
    c += 1
"""

for n in range(10, 20):
    print(n)

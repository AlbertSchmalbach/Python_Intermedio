
v = input('Ingrese un Caracter: ')

if v == 'a' or v == 'A':
    print(v, 'ES VOCAL')
elif v == 'e' or v == 'E':
    print(v, 'ES VOCAL')
elif v == 'i' or v == 'I':
    print(v, 'ES VOCAL')
elif v == 'o' or v == 'O':
    print(v, 'ES VOCAL')
elif v == 'u' or v == 'U':
    print(v, 'ES VOCAL')
else:
    print(v, 'NO ES VOCAL')
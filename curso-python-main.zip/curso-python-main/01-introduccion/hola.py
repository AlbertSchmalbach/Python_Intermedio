
print("Hola Mundo")


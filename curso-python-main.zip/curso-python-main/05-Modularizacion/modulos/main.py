import febonacci
import sys
import builtins
#from febonacci import fibo, fibo2
#from febonacci import *
#import febonacci as f
#from febonacci import fibo as f1
#from febonacci import fibo2 as f2

#f1(100)

#print(f2(100))

print(dir(builtins))